readme.md
diff between version 2.8 (<) and version 2.9 (>)
9,10c9,10
< 	* Minimum required NVDA version: 2022.1
< 	* Last NVDA version tested: 2024.1
---
> 	* Minimum required NVDA version: 2023.1
> 	* Last NVDA version tested: 2024.4
18c18
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/radioSureAccessEnhancement/radioSureAccessEnhancement-2.8.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/radioSureAccessEnhancement/radioSureAccessEnhancement-2.9.nvda-addon
