readme.md
diff between version 2.11 (<) and version 2.12 (>)
3c3
< * Author: PaulBer19 (paulber19@laposte.net)
---
> * Author: PaulBer19 <paulber19@laposte.net>
18c18
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/radioSureAccessEnhancement/radioSureAccessEnhancement-2.11.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/radioSureAccessEnhancement/radioSureAccessEnhancement-2.12.nvda-addon
