readme.md
diff between version 2.9.1 (<) and version 2.10 (>)
9,10c9,10
< 	* Minimum required NVDA version: 2023.1
< 	* Last NVDA version tested: 2024.4
---
> 	* Minimum required NVDA version: 2024.1
> 	* Last NVDA version tested: 2025.1
18c18
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/radioSureAccessEnhancement/radioSureAccessEnhancement-2.9.1.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/radioSureAccessEnhancement/radioSureAccessEnhancement-2.10.nvda-addon
