readme.md
diff between version 2.7.1 (<) and version 2.8 (>)
1c1
< # radioSure Internet Radio Player : accessibility enhancement #
---
> # RadioSure Internet Radio Player : accessibility enhancement #
3,4c3,4
< * Author : PaulBer19
< * URL : paulber19@laposte.net
---
> * Author: PaulBer19 (paulber19@laposte.net)
> * URL: [https://github.com/paulber19/radioSureAccessEnhancementNVDAAddon.git][3]
9,10c9,11
< 	* Minimum required NVDA version: 2020.4
< 	* Last NVDA version tested: 2023.1
---
> 	* Minimum required NVDA version: 2022.1
> 	* Last NVDA version tested: 2024.1
> 
17c18
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/radioSureAccessEnhancement/radioSureAccessEnhancement-2.7.1.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/radioSureAccessEnhancement/radioSureAccessEnhancement-2.8.nvda-addon
18a20
> [3]:https://github.com/paulber19/radioSureAccessEnhancementNVDAAddon.git
